-- ============================================================
-- Clock in / out  (free-standing time tracking)
-- Run this in Supabase SQL Editor after the main schema.
-- ============================================================

create table if not exists public.time_entries (
  id          uuid primary key default gen_random_uuid(),
  employee_id uuid not null references public.employees(id) on delete cascade,
  clock_in    timestamptz not null default now(),
  clock_out   timestamptz,
  created_at  timestamptz not null default now()
);

create index if not exists time_entries_employee_idx
  on public.time_entries (employee_id, clock_in desc);

-- Stop a person having two open clock-ins at once: at most one row
-- per employee where clock_out is still null.
create unique index if not exists one_open_entry_per_employee
  on public.time_entries (employee_id)
  where clock_out is null;

-- ============================================================
-- Row Level Security
-- ============================================================
alter table public.time_entries enable row level security;

-- Employees manage their own entries.
drop policy if exists "employee reads own entries" on public.time_entries;
create policy "employee reads own entries"
  on public.time_entries for select to authenticated
  using (employee_id = auth.uid());

drop policy if exists "employee inserts own entries" on public.time_entries;
create policy "employee inserts own entries"
  on public.time_entries for insert to authenticated
  with check (employee_id = auth.uid());

drop policy if exists "employee updates own entries" on public.time_entries;
create policy "employee updates own entries"
  on public.time_entries for update to authenticated
  using (employee_id = auth.uid());

-- Managers can read everyone's entries (for timesheets).
drop policy if exists "managers read all entries" on public.time_entries;
create policy "managers read all entries"
  on public.time_entries for select to authenticated
  using (public.is_manager());
